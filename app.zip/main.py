#    BİSMİLLAHİRRAHMANİRRAHİM Fİ EVVELİHİ VEL AHİRİ                                                      #
#    BİSMİLLAHİRRAHMANİRRAHİM                      بسم الله الرحمن الرحيم                              #
##########################################################################################################
#    Şems Suresi 7-9                                                                                     #
#    Nefse ve onu düzgün bir biçimde şekillendirip                                                       # 
#    ona kötülük duygusunu ve takvasını (kötülükten sakınma yeteneğini) ilham edene andolsun ki,         #
#    nefsini arındıran kurtuluşa ermiştir.                                                               #
##########################################################################################################
#    ALLAH, insana beyanı verendir.                                                                      # 
#    insan bu beyanla kötülük yapmakla iyilik yapmak arasında seçim yapar.                               #
#    kötü amellerde veya iyi amellerde bulunanlar karşılığını eksiksiz alacaktır.                        #
#                                                                                                        #
#                                                                                                        #
#                                                                                                        #
#                                                                                                        #
#                                                                                                        #
#                                                                                                        #
#                                                                                                        #
#                                                                                                        #
#                                                                                                        #
#                                                                                                        #
#                                                                                                        #
##########################################################################################################



from app import create_app

app=create_app()
if __name__=="__main__":
    app.run(debug=True)