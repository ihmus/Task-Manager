SELECT *
FROM employees
WHERE last_name LIKE 'S%';
