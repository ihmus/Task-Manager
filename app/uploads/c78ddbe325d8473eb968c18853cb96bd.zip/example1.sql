SELECT *
FROM employees
WHERE LOWER(first_name) LIKE '%an%'
   OR LOWER(first_name) LIKE '%en%';
