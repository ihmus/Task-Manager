SELECT first_name, last_name, salary, hire_date
FROM employees
WHERE salary > 50000
  AND YEAR(hire_date) BETWEEN 1994 AND 1995;
