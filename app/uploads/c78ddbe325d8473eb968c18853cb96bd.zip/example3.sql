SELECT AVG(salary) AS average_salary
FROM employees
WHERE YEAR(hire_date) = 1992;
