SELECT (MAX(salary) - MIN(salary)) AS salary_difference
FROM employees
WHERE title IN ('Senior Engineer', 'Senior Staff');
